def helloWorld():
    return "Hello World"

test = helloWorld()
print(test)